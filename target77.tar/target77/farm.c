/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_350(unsigned *p)
{
    *p = 1216588071U;
}

unsigned addval_392(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_222()
{
    return 3267856712U;
}

unsigned getval_290()
{
    return 4244947928U;
}

void setval_154(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_161(unsigned x)
{
    return x + 3351742792U;
}

unsigned getval_303()
{
    return 3281031256U;
}

unsigned getval_420()
{
    return 3281016972U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_478(unsigned x)
{
    return x + 3677929737U;
}

void setval_213(unsigned *p)
{
    *p = 3246981893U;
}

void setval_137(unsigned *p)
{
    *p = 3526940297U;
}

unsigned getval_479()
{
    return 3286272320U;
}

unsigned addval_466(unsigned x)
{
    return x + 2425542281U;
}

void setval_192(unsigned *p)
{
    *p = 3224950281U;
}

unsigned addval_455(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_289(unsigned x)
{
    return x + 3767093385U;
}

unsigned getval_438()
{
    return 4140026377U;
}

unsigned addval_444(unsigned x)
{
    return x + 3380926081U;
}

void setval_135(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_293(unsigned x)
{
    return x + 3229144713U;
}

void setval_445(unsigned *p)
{
    *p = 2462746959U;
}

unsigned getval_273()
{
    return 3676357000U;
}

unsigned getval_260()
{
    return 2425408137U;
}

unsigned addval_338(unsigned x)
{
    return x + 3678978441U;
}

unsigned addval_433(unsigned x)
{
    return x + 3281177225U;
}

unsigned addval_287(unsigned x)
{
    return x + 3767093823U;
}

unsigned getval_153()
{
    return 3536112265U;
}

unsigned addval_374(unsigned x)
{
    return x + 3374372505U;
}

void setval_344(unsigned *p)
{
    *p = 3682912905U;
}

unsigned getval_364()
{
    return 2430634313U;
}

unsigned getval_469()
{
    return 3674789515U;
}

unsigned getval_196()
{
    return 3286272329U;
}

unsigned addval_367(unsigned x)
{
    return x + 3682910601U;
}

unsigned getval_456()
{
    return 3221799304U;
}

unsigned addval_234(unsigned x)
{
    return x + 2430634344U;
}

void setval_226(unsigned *p)
{
    *p = 3267463439U;
}

void setval_377(unsigned *p)
{
    *p = 3523789197U;
}

unsigned addval_281(unsigned x)
{
    return x + 3523794569U;
}

unsigned getval_243()
{
    return 3281046155U;
}

unsigned getval_181()
{
    return 3224947341U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
